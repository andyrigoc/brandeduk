// Popup Contact - Get in Touch
(function() {
  var hero3 = document.getElementById('hero3');
  var popup = document.getElementById('popupContact');
  var overlay = document.getElementById('popupOverlay');
  var closeBtn = document.getElementById('popupContactClose');
  var form = document.getElementById('contactQuickForm');
  
  if (!hero3 || !popup) return;
  
  // Open popup when clicking hero3
  hero3.addEventListener('click', function(e) {
    e.preventDefault();
    openPopup();
  });
  
  // Close popup
  if (closeBtn) {
    closeBtn.addEventListener('click', closePopup);
  }
  
  if (overlay) {
    overlay.addEventListener('click', closePopup);
  }
  
  // Close on escape key
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape' && popup.classList.contains('active')) {
      closePopup();
    }
  });
  
  function openPopup() {
    popup.classList.add('active');
    overlay.classList.add('active');
    document.body.style.overflow = 'hidden';
  }
  
  function closePopup() {
    popup.classList.remove('active');
    overlay.classList.remove('active');
    document.body.style.overflow = '';
  }
  
  // Form submit handler
  if (form) {
    form.addEventListener('submit', function(e) {
      e.preventDefault();
      
      var name = document.getElementById('contactName').value;
      var email = document.getElementById('contactEmail').value;
      var message = document.getElementById('contactMessage').value;
      
      // Here you would send the form data to your server
      console.log('Form submitted:', { name, email, message });
      
      // Show success feedback
      alert('Thanks for your message! We\'ll get back to you soon.');
      closePopup();
      form.reset();
    });
  }
})();
